 CREATE TABLE books (title varchar, author varchar, year int);
 INSERT INTO books (title, author, year)
        VALUES('Cryptonomicon', 'Neal Stephenson', 1998);
    INSERT INTO books (title, author, year)
        VALUES('The Cyberiad', 'Stanislaw Lem', 1985);
    INSERT INTO books (title, author, year)
        VALUES('Friday', 'Robert Heinlein', 1982);
    INSERT INTO books (title, author, year)
        VALUES('The Big U', 'Neal Stephenson', 1988);
